from django.contrib import admin
from .models import (
    CommissionRules,
)
# Register your models here.
admin.site.register(CommissionRules)