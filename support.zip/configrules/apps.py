from django.apps import AppConfig


class ConfigrulesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'configrules'
