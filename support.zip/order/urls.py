from django.urls import path
from django.conf.urls import *
from rest_framework.views import View


urlpatterns = [


]